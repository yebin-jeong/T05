import {groupDB} from './make_group_async.js';
const data = setTimeout(groupDB(), 3000);

console.log('데이터베이스 불러오는 중...');

//{{},{},{}......}

const data_r = data.sort((a,b) => a.region - b.region);
const data_r_y = data_r.sort((a,b) => b.years - a.years);

let group = [];
data_r_y.forEach((i_data,i) => {
    group[i%5] += i_data; 
});

console.log(group);