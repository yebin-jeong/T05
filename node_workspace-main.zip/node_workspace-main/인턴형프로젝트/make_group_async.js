export async function groupDB(){
    const response = await fetch('./program_data.txt');//DB url
    const group = await response.json();
    return group;
}