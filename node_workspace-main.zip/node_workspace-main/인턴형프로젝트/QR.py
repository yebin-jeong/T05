import qrcode
from PIL import Image
import base64
import io

# 이미지 파일을 base64로 인코딩
def encode_image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    return encoded_string.decode('utf-8')

# base64로 인코딩된 이미지를 QR 코드로 생성
def create_qr_code_from_image(image_path, output_path):
    # 이미지 파일을 base64로 인코딩
    encoded_image = encode_image_to_base64(image_path)
    
    # QR 코드 생성
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    
    qr.add_data(encoded_image)
    qr.make(fit=True)
    
    # QR 코드 이미지 생성
    img = qr.make_image(fill='black', back_color='white')
    
    # QR 코드 이미지 저장
    img.save(output_path)

# 예제 사용법
create_qr_code_from_image("input_image.jpg", "output_qr_code.png")
