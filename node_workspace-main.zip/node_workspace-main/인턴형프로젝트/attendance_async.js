export async function attendance(){
    //그룹 데이터 가져오기
    //거기서 포인트 증가시키기
}